# def add(a,b):
#     return a + b
# print(add(5,9))

# def my_function(food):
#     for x in food:
#         print(x)
# fruits = ["apple", "banana", "cherry"]
# my_function(fruits)

# def mul(x):
#     return 5 * x
# print(mul(3))
# print(mul(13))
# print(mul(43))
# print(mul(30))

def personal_info(name="ifra", age="20", phone="03023315161"):
    print(f"name: {name}")
    print(f"age: {age}")
    print(f"phone: {phone}")

personal_info()
personal_info("sana", "21", "03025161")