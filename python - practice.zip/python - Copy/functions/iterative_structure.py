# for i in range(10):
#     print("hello world")

# fruit = ["apple", "banana", "cherry"]
# for f in fruit:
#     print(f)

# for b in "banana":
#     print(b)

# for i in range(1,34,9):
#     print(i)
# mylist = [10,20,30,40,50,60,70,80,90,100]
# for i in range(len(mylist)):
#     print(i,mylist[i])

mydict = {
    "brand ":"ford",
    "model ":"mustang",
    "year": 2013,
    "year" :1964
}
print(mydict)
for dc in mydict.values():
    print(dc)