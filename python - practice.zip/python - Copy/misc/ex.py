# fruit = ["mango", "banana", "apple", "orange", "kiwi"]
# fruit.append("grape")
# fruit.remove("apple")
# fruit.reverse()
# print(fruit)

# vehicles = ("car","bike","bus","cycle")
# vehicles[1] = ("scooter")  # This will raise a TypeError because tuples are immutable

# for i in vehicles:
#     print(i)

# set1 = {1, 2, 3, 4}  
# set2 = {3, 4, 5, 6}

# print(set1.union(set2))
# print(set1.intersection(set2))
# set1.add(5)
# print(set1)
# set2.remove(5)
# print(set2)


# student = {
#     "name": "Ali",
#     "age": 20,
#     "grade": "A"
# }
# student.update({"city": "Lahore"})
# student.update({"grade": "B"})
# print(student)
# print(student.keys())
# print(student.values())

# number = int(input("enter any number:"))
# if(number>0):
#     print("the number is positive")
# elif(number<0):
#     print("the number is negtive")
# else:
#     print("the number is zero")

# for i in range(1,20):
#     if (i%2 == 0):
#         print(f"{i} is even")


# name = []
# for i in range(2):
#     name.append(input("enter your name: ").upper())
# print(name)
# print(len(name))
# up = sorted(name)
# print(up)
# name.sort()
# print(name)
