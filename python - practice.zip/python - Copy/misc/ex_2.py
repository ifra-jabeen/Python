# while True:
#     user_input = input("enter a string: ")
#     if user_input.lower() == "exit":
#         print("you guess right")
#         break
#     else:
#         print("try again not that string")
#         continue

