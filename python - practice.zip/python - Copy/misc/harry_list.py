# list = [1,2,4,"ifra","yes",3.5]
# list[1:3] = ["blackcurrant", "watermelon"]
# print(list)
# print(list[-2])
# if "ra" in "ifra":
#     print("yes") 
# else:
#     print("no")

# if "ifra" in list:
#     print("yes")
# else:
#     print("no")


# starting from index 1
# print(list[1:])
#2 jump jumpimg concept
# print(list[1:4:2])

thislist = ["apple", "banana", "cherry"]
tropical = ["amna", "ali", "fahad"]
# thislist.insert(1,"orange")
# thislist.extend(tropical)
# thislist.append("ifra")
# thislist.remove("banana")
# del thislist[2]
# thislist.pop(0)
thislist.clear()
print(thislist)