# a = 2
# b = 3
# c = a
# a = b
# b = c
# print( a, b)

a = 2
b = 3
a = a+b #5
b =a-b #5-3 =2
a = a-b #5 -2 = 3
print(a, b)