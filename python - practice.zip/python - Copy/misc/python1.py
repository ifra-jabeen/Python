age = input("enter you age: ")
if(age==18):
    print("you cant drive")
elif(age> str(18)):
    print("you can drive")
elif(age<str("18")):
    print("you cant drive")
else:
    print("you are not eligible to drive")