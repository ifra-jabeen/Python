# for num in range(1,6):
#  print(num)

# my_list = [1,2,3,4,5,6,7,8,9,10]
# for i in range(len(my_list)):
#  print(i, my_list[i])

dis= {
  "name": "ifra",
  "age": "20",
  "uni": "riphah"
 }
for key,value in dis.items():
    print(f"the value corresponding to the key {key} is {value}")