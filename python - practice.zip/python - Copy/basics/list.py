# list = ['apple','apple','banana','orange']
# print(len(list))
# print(list)
# print(type(list))

# thislist = ["apple", "banana", "cherry", "orange", "kiwi", "melon", "mango"]
# print(thislist[2:5])
# thislist[1:4] = ["apple"]
# print(thislist.insert(1,"hello"))
# print(thislist.pop(1))
# print(thislist.clear())
# print(thislist)

# thislist = [10, 90, 30, 120, 70]
# thislist.sort()
# print(thislist)
# print(sorted(thislist))
# thislist.reverse()
# print(reversed(thislist))
# thislist.copy()
# print(thislist)

original = [1, 2, 3]
new_list = original.copy()

new_list.insert(4,1)

print(original)   # [1, 2, 3]
print(new_list)   # [1, 2, 3, 1]


# list = [1,2,4,"ifra","yes",3.5]
# list[1:3] = ["blackcurrant", "watermelon"]
# print(list)
# print(list[-2])
# if "ra" in "ifra":
#     print("yes") 
# else:
#     print("no")

# if "ifra" in list:
#     print("yes")
# else:
#     print("no")


# starting from index 1
# print(list[1:])
#2 jump jumpimg concept
# print(list[1:4:2])

thislist = ["apple", "banana", "cherry"]
tropical = ["amna", "ali", "fahad"]
# thislist.insert(1,"orange")
# thislist.extend(tropical)
# thislist.append("ifra")
# thislist.remove("banana")
# del thislist[2]
# thislist.pop(0)
thislist.clear()
print(thislist)




# a = 2.3
# print(type(a))

