# print("enter a string")
# name = input()
# capitalized_text = name.upper()
# lowercase_text = name.lower()
# print("capitalized text is: ", capitalized_text)
# print("lowercase text is: ", lowercase_text)

a =" hey my name is ifra "
print(a)
white_space = a.strip()
print(white_space)
word_list = a.split()
print(word_list)

replaced_text = a.replace("my","your")
print(replaced_text)