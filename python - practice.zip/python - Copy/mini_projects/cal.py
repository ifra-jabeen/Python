 
# 
# chose = int(input("" 
# "Enter 1 for addition," 
# " 2 for subtraction, " 
# "3 for multiplication, " 
# "4 for division: "))
# if chose == 1:
#     num1 = int(input("enter a 1st number: "))
#     num2 = int(input("enter a 2nd number: "))
#     result = num1 + num2
#     print(f"The result of addition is: {result}")
# elif chose == 2:
#      num1 = int(input("enter a 1st number: "))
#      num2 = int(input("enter a 2nd number: "))
#      result = num1 - num2
#      print(f"The result of subtraction is: {result}")
# elif chose == 2:
#      num1 = int(input("enter a 1st number: "))
#      num2 = int(input("enter a 2nd number: "))
#      result = num1 * num2
#      print(f"The result of multiplication is: {result}")
# elif chose == 2:
#      num1 = float(input("enter a 1st number: "))
#      num2 = float(input("enter a 2nd number: "))
#      result = num1 / num2
#      print(f"The result of division is: {result}")
# else:
#     print("Invalid choice. Please enter a number between 1 and 4.")



# choice = int(input("Enter your choice (1-5): "))
# match choice:
#     case 1:
#         num1 = int(input("enter a 1st number: "))
#         num2 = int(input("enter a 2nd number: "))
#         result = num1 + num2
#         print(f"The result of addition is: {result}")
#     case 2:
#         num1 = int(input("enter a 1st number: "))
#         num2 = int(input("enter a 2nd number: "))
#         result = num1 - num2
#         print(f"The result of subtraction is: {result}")
#     case 3:
#         num1 = int(input("enter a 1st number: "))
#         num2 = int(input("enter a 2nd number: "))
#         result = num1 * num2
#         print(f"The result of multiply is: {result}")
#     case 4:
#         num1 = float(input("enter a 1st number: "))
#         num2 = float(input("enter a 2nd number: "))
#         result = num1 / num2
#         print(f"The result of Division is: {result}")
#     case 5:
#         print("exit")
#     case _:
#         print("Invalid choice. Please enter a number between 1 and 4.")